#!/usr/bin/env python3
"""Ursa Catchum character sheet — built on the locked Lilly/Stabby template.
Three pages, starlight-purple theme, kid language, 2024 rules. All numbers
image-verified from ursa5.pdf and Session_7.docx; summons verified vs 2024 SRD.
"""
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                Image, PageBreak, KeepTogether)
from reportlab.lib.enums import TA_LEFT, TA_CENTER

# ---- Theme: starlight purple ----
PURPLE      = colors.HexColor('#6B4FA8')   # primary
PURPLE_DK   = colors.HexColor('#4A357A')
PURPLE_LT   = colors.HexColor('#EDE7F6')   # pale fill
PURPLE_MID  = colors.HexColor('#B9A4DC')
INK         = colors.HexColor('#2A2333')
GREY        = colors.HexColor('#555555')
LINE        = colors.HexColor('#C9B9E6')

styles = getSampleStyleSheet()

def S(name, **kw):
    base = kw.pop('parent', styles['Normal'])
    return ParagraphStyle(name, parent=base, **kw)

title_st   = S('t', fontName='Helvetica-Bold', fontSize=26, textColor=PURPLE, leading=28)
sub_st     = S('s', fontName='Helvetica', fontSize=10.5, textColor=GREY, leading=13)
flav_st    = S('f', fontName='Helvetica-Oblique', fontSize=9.5, textColor=INK, leading=12.5)
h2_st      = S('h2', fontName='Helvetica-Bold', fontSize=13, textColor=PURPLE, leading=15,
               spaceBefore=8, spaceAfter=3)
body_st    = S('b', fontName='Helvetica', fontSize=8.6, textColor=INK, leading=11)
small_it   = S('si', fontName='Helvetica-Oblique', fontSize=8, textColor=GREY, leading=10)
cell_st    = S('c', fontName='Helvetica', fontSize=8.3, textColor=INK, leading=10)
cellb_st   = S('cb', fontName='Helvetica-Bold', fontSize=8.3, textColor=INK, leading=10)
white_lbl  = S('wl', fontName='Helvetica-Bold', fontSize=7.2, textColor=colors.white,
               leading=8, alignment=TA_CENTER)
big_num    = S('bn', fontName='Helvetica-Bold', fontSize=15, textColor=INK,
               leading=16, alignment=TA_CENTER)
note_st    = S('n', fontName='Helvetica', fontSize=8.4, textColor=INK, leading=11)

def stat_strip(pairs):
    """Top stat strip: list of (LABEL, big value) tuples."""
    labels = [Paragraph(l, white_lbl) for l, _ in pairs]
    vals   = [Paragraph(str(v), big_num) for _, v in pairs]
    t = Table([labels, vals], colWidths=[ (7.3*inch)/len(pairs) ]*len(pairs))
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0), PURPLE),
        ('BACKGROUND',(0,1),(-1,1), PURPLE_LT),
        ('GRID',(0,0),(-1,-1), 0.5, colors.white),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('TOPPADDING',(0,0),(-1,0),3),('BOTTOMPADDING',(0,0),(-1,0),3),
        ('TOPPADDING',(0,1),(-1,1),5),('BOTTOMPADDING',(0,1),(-1,1),5),
    ]))
    return t

def ability_strip(abils):
    """abils: list of (LABEL, score, mod)."""
    labels = [Paragraph(l, white_lbl) for l,_,_ in abils]
    rows_score = [Paragraph(str(s), big_num) for _,s,_ in abils]
    mod_st = S('m', fontName='Helvetica', fontSize=8.5, textColor=GREY, alignment=TA_CENTER, leading=9)
    rows_mod = [Paragraph(m, mod_st) for _,_,m in abils]
    t = Table([labels, rows_score, rows_mod], colWidths=[7.3*inch/6]*6)
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0), PURPLE),
        ('BACKGROUND',(0,1),(-1,2), PURPLE_LT),
        ('GRID',(0,0),(-1,-1),0.5, colors.white),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('TOPPADDING',(0,0),(-1,0),2),('BOTTOMPADDING',(0,0),(-1,0),2),
        ('TOPPADDING',(0,1),(-1,1),3),('BOTTOMPADDING',(0,1),(-1,1),0),
        ('TOPPADDING',(0,2),(-1,2),0),('BOTTOMPADDING',(0,2),(-1,2),3),
    ]))
    return t

def section_table(data, col_widths, header=True, header_bg=PURPLE):
    t = Table(data, colWidths=col_widths)
    style = [
        ('VALIGN',(0,0),(-1,-1),'TOP'),
        ('GRID',(0,0),(-1,-1),0.5, LINE),
        ('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),
        ('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white, PURPLE_LT]),
    ]
    if header:
        style += [('BACKGROUND',(0,0),(-1,0), header_bg),
                  ('TEXTCOLOR',(0,0),(-1,0), colors.white),
                  ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),
                  ('FONTSIZE',(0,0),(-1,0),8.3)]
    t.setStyle(TableStyle(style))
    return t

def callout(text):
    p = Paragraph(text, note_st)
    t = Table([[p]], colWidths=[7.3*inch])
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,-1), PURPLE_LT),
        ('BOX',(0,0),(-1,-1),1, PURPLE),
        ('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),
        ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),
    ]))
    return t

story = []

# ============================ PAGE 1 ============================
hdr = Table([[
    Image('ursa_new.png', width=1.35*inch, height=1.35*inch),
    [Paragraph('Ursa Catchum', title_st),
     Paragraph('Human (Mark of Handling) &bull; Druid (Circle of Stars) &bull; Level 5', sub_st),
     Spacer(1,3),
     Paragraph('The starwatcher. Ursa reads the night sky like a map, calls down '
               'starlight and beast-spirits, and follows the constellations toward his destiny.', flav_st)]
]], colWidths=[1.5*inch, 5.8*inch])
hdr.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),
                         ('LEFTPADDING',(1,0),(1,0),10)]))
story.append(hdr)
story.append(Spacer(1,8))

story.append(stat_strip([('ARMOR CLASS',18),('HIT POINTS',38),('SPEED','30 ft'),
                         ('INITIATIVE','+2'),('SAVE DC',16),('SPELL ATK','+8')]))
story.append(Spacer(1,4))
story.append(ability_strip([('STR',8,'-1'),('DEX',14,'+2'),('CON',14,'+2'),
                            ('INT',12,'+1'),('WIS',20,'+5'),('CHA',8,'-1')]))
story.append(Paragraph('Best saves: Wis +8, Int +4. WIS powers all his magic.', small_it))

story.append(Paragraph("All of Ursa's Skills", h2_st))
skills = [
    ('Acrobatics +2','History +1','Nature +1','Sleight of Hand +2'),
    ('<b>Animal Handling +8</b>','Insight +5','<b>Perception +8</b>','Stealth +2'),
    ('Arcana +1','Intimidation -1','Performance -1','<b>Survival +8</b>'),
    ('Athletics -1','Investigation +1','Persuasion -1',''),
    ('Deception -1','Medicine +5','Religion +1',''),
]
sk_data = [[Paragraph(c, cell_st) for c in row] for row in skills]
sk = Table(sk_data, colWidths=[1.825*inch]*4)
sk.setStyle(TableStyle([
    ('BOX',(0,0),(-1,-1),0.5, LINE),
    ('INNERGRID',(0,0),(-1,-1),0.3, PURPLE_LT),
    ('TOPPADDING',(0,0),(-1,-1),2.5),('BOTTOMPADDING',(0,0),(-1,-1),2.5),
    ('LEFTPADDING',(0,0),(-1,-1),5),
]))
story.append(sk)
story.append(Paragraph('Purple = trained. Best: Animal Handling, Perception & Survival +8. '
                       'Passive Perception 18 — almost nothing sneaks past him.', small_it))

story.append(Paragraph("What Ursa Does in a Fight", h2_st))
atk = [
    ['Attack','To Hit','Damage'],
    ['Staff of Waking Constellations (+1)','+6 (7)','1d8+3 bludgeoning (a starlit quarterstaff)'],
    ['Guiding Bolt (1st, from Staff or Star Map)','+8 (9)','4d6 radiant + 1d4 (Starseed); next hit on it has advantage'],
    ['Star-Arrow (Starry Form: Archer)','+8 (9)','1d8+5 radiant, one enemy within 60 ft (bonus action)'],
    ['Primal Savagery (cantrip)','+8 (9)','2d10 acid (close-up bite of magic)'],
    ['Starry Wisp (cantrip)','+8 (9)','2d8 radiant + 1d4 (Starseed), lights up the target (60 ft)'],
]
atk_data = [[Paragraph(c, cellb_st if i==0 else cell_st) for c in row]
            for i,row in enumerate(atk)]
story.append(section_table(atk_data, [3.0*inch, 0.9*inch, 3.4*inch]))
story.append(Paragraph('The number in (parentheses) is his to-hit while his <b>Starry Form</b> is glowing \u2014 '
    'the Amulet of Guiding Light gives +1 to attacks (and saves) for him and nearby friends. He keeps it on, '
    'so that\u2019s usually his real number.', small_it))

story.append(Spacer(1,4))
story.append(callout(
    "<b>How Ursa's turn works:</b> His <b>summoned spirit acts on its own turn for free</b> \u2014 Ursa just "
    "tells it what to do (no action needed). His <b>bonus action</b> each turn goes to one move: fire a "
    "<b>star-arrow</b> (Starry Form: Archer, 1d8+5 radiant), move a <b>Moonbeam</b> or <b>Flaming Sphere</b>, "
    "or cast <b>Healing Word</b>. And he still <b>casts a spell or cantrip with his action</b> the same turn.<br/>"
    "<b>Free Guiding Bolts:</b> before touching his real spell slots, he can throw about "
    "<b>8 Guiding Bolts a day</b> for free \u2014 <b>3</b> from the Star Map (per long rest) plus "
    "<b>up to 5</b> from the Staff's charges. So he can spam radiant comets all session and save his slots.<br/>"
    "<b>Keep Starry Form going:</b> if he runs out of Wild Shape uses, he can spend a <b>spell slot</b> "
    "(no action, once a turn) to get one back \u2014 so the starlight never has to switch off. While it glows, "
    "he and nearby friends also get <b>+1 to saving throws</b> (Amulet of Guiding Light).<br/>"
    "<b>Starseed (+1d4 radiant):</b> rides on his <b>druid spells</b> that deal radiant \u2014 Guiding Bolt, Moonbeam, Starry Wisp. It does <b>not</b> add to the Starry Form Archer arrow (that\u2019s a form feature, not a spell)."))

# Two summon stat blocks side by side
story.append(Paragraph("Ursa's Summoned Spirits", h2_st))

def summon_block(title, lines):
    rows = [[Paragraph(title, S('st', fontName='Helvetica-Bold', fontSize=9,
                                textColor=colors.white, leading=11))]]
    for ln in lines:
        rows.append([Paragraph(ln, S('sl', fontName='Helvetica', fontSize=7.8,
                                     textColor=INK, leading=9.5))])
    t = Table(rows, colWidths=[3.55*inch])
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(0,0), PURPLE_DK),
        ('BACKGROUND',(0,1),(0,-1), PURPLE_LT),
        ('BOX',(0,0),(-1,-1),0.8, PURPLE),
        ('LINEBELOW',(0,0),(0,0),0.8, PURPLE),
        ('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),
        ('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3),
    ]))
    return t

beast = summon_block("Bestial Spirit — Summon Beast (2nd)", [
    "<b>AC</b> 13 &nbsp; <b>HP</b> 30 &nbsp; <b>Speed</b> 40 ft (Land), or fly/swim 30 ft",
    "Pick Air, Land, or Water when summoned.",
    "<b>Maul/Rend:</b> +8 to hit, <b>1d8+6</b> damage, 1 attack.",
    "Flyby (Air) — no opportunity attacks. Great scout & striker.",
    "Shares Ursa's turn; obeys his commands for free.",
])
fey = summon_block("Fey Spirit — Summon Fey (3rd)", [
    "<b>AC</b> 15 &nbsp; <b>HP</b> 30 &nbsp; <b>Speed</b> 40 ft, fly 40 ft",
    "<b>Fey Blade:</b> +8 to hit, <b>2d6+6 force</b>, 1 attack.",
    "<b>Fey Step:</b> teleport up to 30 ft, then its mood triggers:",
    "<i>Fuming:</i> advantage on its next attack this turn.",
    "<i>Mirthful:</i> foe within 10 ft, Wis save DC 16 or Charmed.",
    "<i>Tricksy:</i> fills a 10-ft cube with magical Darkness.",
])
both = Table([[beast, fey]], colWidths=[3.65*inch, 3.65*inch])
both.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),
                          ('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(0,0),10)]))
story.append(both)

story.append(PageBreak())

# ============================ PAGE 2 ============================
story.append(Paragraph('Ursa Catchum', S('p2t', fontName='Helvetica-Bold',
            fontSize=15, textColor=PURPLE, leading=18, spaceAfter=2)))
story.append(Paragraph('Page 2 — Powers, Gear &amp; Story', sub_st))
story.append(Spacer(1,8))

story.append(Paragraph("Ursa's Special Powers", h2_st))
powers = [
    ('Starry Form (Bonus Action)', 'Spend a Wild Shape use to glow with starlight (10-ft bright light, 10 min). '
        'Pick a constellation each time:'),
    ('&nbsp;&nbsp;&bull; Archer', 'Bonus action: fire a star-arrow at one enemy within 60 ft for <b>1d8+5 radiant</b>.'),
    ('&nbsp;&nbsp;&bull; Chalice', 'When he heals someone with a spell slot, he or a nearby friend also heals <b>1d8+5</b>.'),
    ('&nbsp;&nbsp;&bull; Dragon', 'Treat a roll of 9 or lower as a 10 on Int/Wis checks and concentration saves — super steady.'),
    ('Wild Shape (2 uses)', 'Two uses that fuel his Starry Forms (or turn into a beast he has seen). Regain <b>1 on a short rest</b>, all on a long rest.'),
    ('Wild Resurgence', 'Once per turn (no action), he can spend a <b>spell slot</b> to get back <b>one Wild Shape use</b> \u2014 so he can keep his Starry Form going even after his 2 uses are spent.'),
    ('Star Map', 'His star chart is a magic focus. Free <b>Guiding Bolt</b> 3×/day even without the Staff. Backup focus he still carries.'),
    ('Wild Intuition', 'Add 1d4 to any Animal Handling or Nature check.'),
    ('Primal Connection (1/short rest)', 'Cast Animal Friendship or Speak with Animals for free, no materials.'),
    ('The Bigger They Are', 'Can charm or talk to beasts AND monstrosities (if their Intelligence is 3 or lower).'),
    ('Mark of Handling', 'His dragonmark lets him read animals\u2019 feelings and calm wild or magical creatures with ease.'),
]
pw_data = [[Paragraph(f'<b>{n}</b>', cell_st), Paragraph(d, cell_st)] for n,d in powers]
story.append(section_table(pw_data, [2.15*inch, 5.15*inch], header=False))

story.append(Paragraph("Ursa's Stuff", h2_st))
gear = [
    ('Staff of Waking Constellations<br/><i>(new! \u2605 Elaria\u2019s gift)</i>',
     'His Wraithpine relic. <b>+1 quarterstaff &amp; druidic focus.</b> Holds <b>5 charges</b> (regain 1d4+1 at dawn): '
     '<i>Guiding Bolt</i> (1), <i>Faerie Fire</i> (1), <i>Moonbeam</i> (2). '
     '<b>Starseed:</b> once a turn, when a druid spell deals radiant damage, add <b>+1d4 radiant</b>. '
     '<b>Starlight:</b> bonus action to light a soft 10-ft glow and get advantage on night-navigation. <b>Attuned.</b>'),
    ('Star Map', 'A Tiny star chart that doubles as a spellcasting focus. Free Guiding Bolt 3×/day. (Backup focus.)'),
    ('Amulet of Guiding Light', '<b>Guiding Light:</b> during Starry Form, Ursa and allies in the bright light get +1 to attacks and saves. '
        '<b>Starry Glow (1/day, reaction):</b> when he or a nearby ally is hit, the attacker takes 2d8 radiant and may be blinded (Con save DC 15). '
        '<b>Celestial Resilience (2/day):</b> reroll a natural 1.'),
    ('Spiked Armor &amp; Shield', 'Dwarf-made spiked armor plus a shield — together they make his <b>AC 18</b>.'),
    ('Explorer\u2019s Pack', 'Backpack, bedroll, mess kit, tinderbox, 10 torches, 10 days of rations, waterskin, 50 ft of rope.'),
    ('Three Enchanted Potatoes', 'His mysterious quest trinket — the strange spuds tied to his father\u2019s disappearance.'),
]
g_data = [[Paragraph(n, cell_st), Paragraph(d, cell_st)] for n,d in gear]
story.append(section_table(g_data, [1.9*inch, 5.4*inch], header=False))

story.append(Paragraph("Ursa's Story", h2_st))
story.append(Paragraph(
    "Ursa grew up under the wide, dark skies of a quiet farming village, raised on his father\u2019s tales of the "
    "stars and the secrets they keep. His father — a wandering sky-reader and beast-friend who carried the "
    "<b>Mark of Handling</b> — vanished one night chasing a mystery tied to a handful of <b>enchanted potatoes</b>, "
    "leaving Ursa only a star chart and a promise to follow it. Ursa studied the constellations until he could call "
    "their light down to earth, becoming a <b>Druid of the Circle of Stars</b>. Determined to find out what happened "
    "to his father, he set out and crossed paths with <b>Lilly</b> and her Essence Sphere, and the wild goblin "
    "<b>Stabby</b>. The three became an unlikely family, chasing planar cracks, enchanted potatoes, and the guiding "
    "hand of the sleeping goddess <b>Elaria</b>.", body_st))

per = [
    ('Personality', 'Determined and resilient. Quiet and watchful, but never gives up. '
        '\u201cI won\u2019t stop until I find the answers.\u201d'),
    ('Ideal — Fate', 'The stars guide every destiny, and his path is part of a greater cosmic plan. '
        '\u201cThe stars have written my path, and I will follow it.\u201d'),
    ('Bond — His Crew', 'Fiercely loyal to Lilly and Stabby, his new family. '
        '\u201cTogether, we will uncover the truth and face whatever comes.\u201d'),
    ('Flaw — Fear of Failure', 'He worries he can\u2019t live up to his father\u2019s legacy, which can make him '
        'hesitate or push too hard. \u201cWhat if I\u2019m not strong enough?\u201d'),
]
per_cells = [Paragraph(f'<b>{t}</b><br/>{d}', S('pc', fontName='Helvetica', fontSize=8,
             textColor=INK, leading=10)) for t,d in per]
pt = Table([[per_cells[0], per_cells[1]],[per_cells[2], per_cells[3]]],
           colWidths=[3.65*inch,3.65*inch])
pt.setStyle(TableStyle([
    ('BOX',(0,0),(-1,-1),0.5, LINE),('INNERGRID',(0,0),(-1,-1),0.5, LINE),
    ('BACKGROUND',(0,0),(-1,-1), PURPLE_LT),
    ('VALIGN',(0,0),(-1,-1),'TOP'),
    ('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),
    ('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),
]))
story.append(Spacer(1,3))
story.append(pt)
story.append(Spacer(1,4))
story.append(Paragraph('<b>Fun Facts:</b> &nbsp;Ursa is a boy, follows the dragon-god Bahamut, and was a Folk Hero '
    'before adventuring. &bull; Auburn hair, purple eyes, freckles, and a fur-lined cloak for cold nights. '
    '&bull; He speaks Common, Sylvan, and Druidic (a secret nature-language for hidden messages).', small_it))

story.append(PageBreak())

# ============================ PAGE 3 — SPELLBOOK ============================
story.append(Paragraph('Ursa Catchum', S('p3t', fontName='Helvetica-Bold',
            fontSize=15, textColor=PURPLE, leading=18, spaceAfter=2)))
story.append(Paragraph('Page 3 — Spellbook', sub_st))
story.append(Spacer(1,7))
story.append(Paragraph('Slots per day: 4 first-level, 3 second-level, 2 third-level. '
    'Cantrips (\u2605) are free forever. He prepares 10 spells and can swap them on a long rest. '
    'Spell save DC 16, spell attack +8.', small_it))
story.append(Spacer(1,4))

# Spell cards — richer format: name, meta line (action/range/duration), then full mechanics
def spell_card(name, meta, text):
    inner = [
        [Paragraph(f'<b>{name}</b>', S('scn', fontName='Helvetica-Bold', fontSize=9,
                   textColor=PURPLE_DK, leading=11))],
        [Paragraph(meta, S('sct', fontName='Helvetica-Oblique', fontSize=6.8,
                   textColor=GREY, leading=8.2))],
        [Paragraph(text, S('scx', fontName='Helvetica', fontSize=7.6,
                   textColor=INK, leading=9.6))],
    ]
    t = Table(inner, colWidths=[3.55*inch])
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(0,1), PURPLE_LT),
        ('BOX',(0,0),(-1,-1),0.6, PURPLE_MID),
        ('LINEBELOW',(0,1),(0,1),0.4, PURPLE_MID),
        ('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),
        ('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2),
        ('TOPPADDING',(0,2),(0,2),4),('BOTTOMPADDING',(0,2),(0,2),5),
    ]))
    return t

cards = [
    spell_card('\u2605 Primal Savagery',
        'Cantrip \u2022 Action \u2022 Self (5 ft reach) \u2022 Instant',
        'His teeth/claws sharpen with acid. Make a melee spell attack: <b>+8 to hit</b>, '
        '<b>2d10 acid</b> on a hit. No save \u2014 it\u2019s an attack roll. Good when something\u2019s right next to him.'),
    spell_card('\u2605 Starry Wisp',
        'Cantrip \u2022 Action \u2022 60 ft \u2022 Instant',
        'Launch a mote of starlight. Ranged spell attack <b>+8 to hit</b>: <b>2d8 radiant + 1d4</b> (Starseed). '
        'The target glows (dim light) and <b>can\u2019t turn invisible</b> until the end of his next turn. On-theme and reliable.'),
    spell_card('\u2605 Guidance',
        'Cantrip \u2022 Action \u2022 Touch \u2022 Concentration, 1 min',
        'Touch a willing friend. Once before it ends, they add <b>1d4</b> to one ability check '
        '(can roll the d4 after seeing the result). Great before a tricky skill roll.'),
    spell_card('\u2605 Druidcraft',
        'Cantrip \u2022 Action \u2022 30 ft \u2022 Instant',
        'Tiny nature magic: predict the next 24 hr of weather, bloom a flower, make a harmless '
        'sound/smell in a 5-ft cube, or light/snuff a small flame. Pure utility &amp; flavor.'),
    spell_card('Guiding Bolt',
        '1st \u2022 Action \u2022 120 ft \u2022 1 round &nbsp;(Star Map: free 3/day)',
        'Ranged spell attack <b>+8 to hit</b>. On a hit: <b>4d6 radiant + 1d4</b> (Starseed). '
        'The <b>next attack</b> against that target before Ursa\u2019s next turn has <b>advantage</b> \u2014 set up a teammate.'),
    spell_card('Faerie Fire',
        '1st \u2022 Action \u2022 60 ft \u2022 Concentration, 1 min',
        'Foes in a 20-ft cube make a <b>Dex save DC 16</b>; on a fail they\u2019re outlined in light. '
        'Attacks vs them have <b>advantage</b>, and they <b>can\u2019t hide/be invisible</b>. Team-wide accuracy boost.'),
    spell_card('Healing Word',
        '1st \u2022 Bonus Action \u2022 60 ft \u2022 Instant',
        'Heal one creature you can see <b>2d4+5</b> HP \u2014 as a <b>bonus action</b>, so he can still '
        'cast a cantrip or attack the same turn. Best for popping a downed friend back up from range.'),
    spell_card('Goodberry',
        '1st \u2022 Action \u2022 Touch \u2022 lasts 24 hr',
        'Creates <b>10 berries</b>; eating one (an action) heals <b>1 HP</b> and feeds someone for a day. '
        'Cast before a fight to bank 10 little heals the whole party can use.'),
    spell_card('Speak with Animals',
        '1st \u2022 Ritual \u2022 Action \u2022 Self \u2022 10 min',
        'Talk with beasts for 10 min \u2014 they can describe nearby places, monsters, and what they\u2019ve '
        'seen in the last day. Cast as a <b>ritual</b> (no slot) when there\u2019s no rush. Pairs with his animal charm.'),
    spell_card('Animal Friendship',
        '1st \u2022 Action \u2022 30 ft \u2022 24 hr',
        'One beast (Int 3 or lower) makes a <b>Wis save DC 16</b>; on a fail it\u2019s <b>charmed</b> '
        'and friendly for 24 hr. With \u201cThe Bigger They Are,\u201d he can target dumb monstrosities too.'),
    spell_card('Moonbeam',
        '2nd \u2022 Action \u2022 120 ft \u2022 Concentration, 1 min &nbsp;(Staff: 2 charges)',
        'A 5-ft pillar of light. A creature that enters it or starts its turn there makes a <b>Con save DC 16</b>: '
        '<b>2d10 radiant + 1d4</b> (Starseed) on a fail, half on a success. <b>Move it 60 ft</b> each turn as part of the spell.'),
    spell_card('Flaming Sphere',
        '2nd \u2022 Action \u2022 60 ft \u2022 Concentration, 1 min',
        'A 5-ft fire ball. A creature ending its turn within 5 ft makes a <b>Dex save DC 16</b>: <b>2d6 fire</b> on a fail, '
        'half on success. <b>Bonus action to roll it 30 ft</b> (ram a foe to force the save). Lights the area too.'),
    spell_card('Healing Spirit',
        '2nd \u2022 Bonus Action \u2022 60 ft \u2022 Concentration, 1 min',
        'A spirit fills a 5-ft cube. When a friend enters or starts its turn there, heal <b>1d6</b> '
        '(no action) \u2014 up to <b>6 times</b> total. <b>Move it 30 ft</b> with a bonus action. Great in a clustered scrap.'),
    spell_card('Summon Beast',
        '2nd \u2022 Action \u2022 90 ft \u2022 Concentration, 1 hr',
        'Calls the <b>Bestial Spirit</b> (full stats on page 1). It acts right after Ursa on his initiative and '
        'obeys his commands for free. His go-to summon \u2014 a sturdy front-line ally that lasts a whole hour.'),
    spell_card('Call Lightning',
        '3rd \u2022 Action \u2022 120 ft \u2022 Concentration, 10 min',
        'Make a storm cloud. Each turn, use your <b>action</b> to strike: creatures within 5 ft of the point make a '
        '<b>Dex save DC 16</b> \u2014 <b>3d10 lightning</b> on a fail, half on success. +1d10 if it\u2019s already stormy. Repeatable AoE.'),
    spell_card('Summon Fey',
        '3rd \u2022 Action \u2022 90 ft \u2022 Concentration, 1 hr',
        'Calls the <b>Fey Spirit</b> (full stats on page 1). Faster and hits harder than the beast, with a mood power '
        '(Fuming/Mirthful/Tricksy) and a 30-ft teleport. Acts on Ursa\u2019s turn and obeys him for free.'),
]

# Lay cards into a 2-wide grid
rows = []
for i in range(0, len(cards), 2):
    chunk = cards[i:i+2]
    while len(chunk) < 2:
        chunk.append(Paragraph('', body_st))
    rows.append(chunk)
grid = Table(rows, colWidths=[3.66*inch]*2)
grid.setStyle(TableStyle([
    ('VALIGN',(0,0),(-1,-1),'TOP'),
    ('LEFTPADDING',(0,0),(-1,-1),2),('RIGHTPADDING',(0,0),(-1,-1),2),
    ('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3),
]))
story.append(grid)

doc = SimpleDocTemplate('/home/claude/Ursa_Catchum_Sheet.pdf', pagesize=letter,
                        leftMargin=0.55*inch, rightMargin=0.55*inch,
                        topMargin=0.45*inch, bottomMargin=0.4*inch)
doc.build(story)
print('built Ursa_Catchum_Sheet.pdf')
